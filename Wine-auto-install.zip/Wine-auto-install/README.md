# Wine-auto-install
Automate the wine install process 
